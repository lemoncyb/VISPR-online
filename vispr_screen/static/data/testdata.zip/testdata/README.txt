This is a test dataset for VISPR-online.
The data is from HOMO SAPIENS.
You can upload these files to VISPR-online to explore the application.

############## Functions of each file ##############
                               MAGeCK
all.count_normalized.txt  :  sgRNA location file
    mle.gene_summary.txt  :  gene summary file
   mle.sgrna_summary.txt  :  sgRNA summary file
              sgrnas.bed  :  sgRNA location file

                                 Bagel
    test43.foldchange.txt  ： Foldchange file

                                 JACKS
   test_43_gene_JACKS_results.txt  ： Gene Score file
test_43_logfoldchange_means.txt  ： Foldchange file
    test_43_grna_JACKS_results.txt  ：gRNA file 
